import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthStoreService } from '../services/auth-store.service';
import { isAdminRole } from '../utils/admin.utils';

export const guestGuard: CanActivateFn = () => {
  const authStore = inject(AuthStoreService);
  const router = inject(Router);
  const session = authStore.snapshot() ?? authStore.restore();

  if (!session?.token) {
    return true;
  }

  return isAdminRole(session.role)
    ? router.createUrlTree(['/admin/dashboard'])
    : router.createUrlTree(['/workspaces']);
};